Frequently Asked Questions
==========================

Can I use Cerberus to validate objects?
---------------------------------------

Yes. See `Validating user objects with Cerberus <http://nicolaiarocci.com/validating-user-objects-cerberus/>`_.
